# Bluestock Mutual Fund Analytics

A mutual-fund analytics capstone that combines industry indicators, scheme-level performance and risk measures, investor transaction records, portfolio holdings and benchmark observations in a reproducible Python workflow and an interactive Streamlit dashboard.

## Project modules

- **Day 1–3 EDA:** The existing `Bluestock_Day3_EDA/` and `data/processed/` folders in this repository retain the earlier ETL and exploratory-analysis work.
- **Interactive dashboard:** `dashboard/` contains the Streamlit application and its nine input datasets.
- **Master validation:** `run_pipeline.py` validates the dashboard datasets before the app is launched.
- **Final submission files:** `deliverables/Final_Report.pdf` and `deliverables/Bluestock_MF_Presentation.pptx`.

## Dashboard sections

1. Market Overview — AUM, SIP inflows, category inflows and folio trends.
2. Scheme Performance — category/fund-house/risk filters and return comparisons.
3. Risk Analytics — risk-return and risk-adjusted metric exploration.
4. Investor Insights — transaction, age, geography, payment and KYC segmentation.
5. Portfolio Holdings — reported holdings and sector exposure.
6. Data Coverage — row counts, columns and missing-value checks.

## Setup (Windows PowerShell)

From the repository root:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## Validate the datasets

```powershell
python run_pipeline.py
```

## Run the dashboard

```powershell
python -m streamlit run dashboard/app.py
```

Open `http://localhost:8501` if the browser does not open automatically.

## Dataset inventory

| File | Purpose |
|---|---|
| `aum_by_fund_house.csv` | Fund-house AUM snapshots and scheme counts |
| `monthly_sip_inflows.csv` | Monthly SIP contributions and account indicators |
| `category_inflows.csv` | Net inflows by category and month |
| `industry_folio_count.csv` | Industry folio counts by category |
| `scheme_performance.csv` | Returns, benchmark return, alpha, beta and risk statistics |
| `fund_master.csv` | Scheme identifiers, categories, plan and fund attributes |
| `investor_transactions.csv` | Transaction, investor segment and geography fields |
| `portfolio_holdings.csv` | Scheme-level stock holdings and reported sector weights |
| `benchmark_indices.csv` | Benchmark index observations |

## Data and interpretation notes

The dashboard uses static CSV snapshots; it does not fetch live prices or NAVs. Scheme-level performance and risk fields are displayed as supplied and are not recomputed from daily NAV in this dashboard. Portfolio sector totals are descriptive sums of reported holding weights, not an AUM-weighted industry allocation. Folio counts are not the same as unique investors. The investor transaction file should be treated as sensitive analytical data; publish aggregated insights only. This project is educational and is not personalised investment advice.

## Reproducibility and release checklist

- [ ] Install dependencies in a clean virtual environment.
- [ ] `python run_pipeline.py` passes.
- [ ] Dashboard opens and each of its six sections has been checked in a browser.
- [ ] Final PDF and 12-slide presentation are present in `deliverables/`.
- [ ] No `.venv`, secrets, tokens or local machine paths are committed.
- [ ] GitHub commit and `v1.0` tag are visible remotely.

## GitHub release

After copying these files into the existing repository root and checking `git status`, run:

```powershell
git add .
git commit -m "Final: Complete Bluestock MF Capstone"
git tag v1.0
git push origin main
git push origin v1.0
```

If `v1.0` already exists, inspect it before creating another tag. This repository's default branch is `main`.
