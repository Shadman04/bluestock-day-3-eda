# Final self-review checklist

- [ ] All eight project objectives have been checked against the original project brief.
- [ ] All seven deliverables are present and reviewed.
- [ ] All nine CSV datasets are present and readable.
- [ ] `python run_pipeline.py` completes without errors.
- [ ] `python -m streamlit run app.py` opens the dashboard.
- [ ] Dashboard filters and tabs have been manually tested in a browser.
- [ ] PDF report is 15–20 pages and contains final dashboard screenshots.
- [ ] Presentation contains exactly 12 slides and has been rehearsed.
- [ ] No debug output, secrets, credentials or local absolute paths are committed.
- [ ] README setup instructions have been tested on a clean environment.
- [ ] GitHub commit and `v1.0` tag are visible remotely.
- [ ] Optional public dashboard URL, if published, is added to README.
