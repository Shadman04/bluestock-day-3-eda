# Bluestock Mutual Fund Analytics Dashboard

Interactive Streamlit dashboard built from the actual CSV datasets bundled in this project ZIP.

## Included modules
- Market overview: AUM, SIP inflows, category inflows and folio trend
- Scheme performance: category, fund-house and risk-grade filters; rankings and comparison table
- Risk analytics: volatility/return, drawdown/Sharpe and risk-grade distributions
- Investor insights: age group, state, transaction type, payment mode and KYC
- Portfolio holdings: sector and stock-level reported weights
- Data coverage: row counts, column counts and missing-cell checks

## Run locally (Windows PowerShell)
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
streamlit run app.py
```

## Run locally (macOS/Linux)
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
streamlit run app.py
```

The app reads CSV files from `data/` relative to `app.py`. It does not require credentials or an external API.

## Data notes
- The dashboard is snapshot-based, not live market data.
- Scheme risk indicators are displayed from the supplied scheme-performance table; they are not recomputed from daily NAV.
- Holdings weights are summed across the supplied scheme holdings rows and are not AUM-weighted.
- No recommendation is personalized investment advice.
