"""
Bluestock Mutual Fund Analytics Dashboard
Run: streamlit run app.py
All charts are generated from the CSV files bundled in ./data.
"""
from pathlib import Path
import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title="Bluestock | Mutual Fund Analytics", page_icon="📈", layout="wide")
DATA_DIR = Path(__file__).resolve().parent / "data"

FILES = {
    "aum": "aum_by_fund_house.csv",
    "sip": "monthly_sip_inflows.csv",
    "folios": "industry_folio_count.csv",
    "inflows": "category_inflows.csv",
    "performance": "scheme_performance.csv",
    "transactions": "investor_transactions.csv",
    "holdings": "portfolio_holdings.csv",
    "benchmarks": "benchmark_indices.csv",
    "funds": "fund_master.csv",
}

@st.cache_data
def load_csv(filename):
    path = DATA_DIR / filename
    if not path.exists():
        return pd.DataFrame()
    frame = pd.read_csv(path)
    for col in ("date", "month", "transaction_date", "portfolio_date", "launch_date"):
        if col in frame.columns:
            frame[col] = pd.to_datetime(frame[col], errors="coerce")
    return frame

data = {key: load_csv(filename) for key, filename in FILES.items()}
aum, sip, folios = data["aum"], data["sip"], data["folios"]
inflows, perf = data["inflows"], data["performance"]
tx, holdings, benchmarks = data["transactions"], data["holdings"], data["benchmarks"]
funds = data["funds"]

def has(frame, columns):
    return not frame.empty and all(c in frame.columns for c in columns)

def money(value, prefix="₹", suffix=""):
    return f"{prefix}{value:,.0f}{suffix}"

st.title("Bluestock Mutual Fund Analytics")
st.caption("Capstone dashboard · Interactive analysis of the supplied project datasets")
with st.sidebar:
    st.header("Dashboard filters")
    st.caption("Filters apply to scheme-level performance and risk views.")
    categories = sorted(perf["category"].dropna().astype(str).unique()) if has(perf, ["category"]) else []
    houses = sorted(perf["fund_house"].dropna().astype(str).unique()) if has(perf, ["fund_house"]) else []
    risks = sorted(perf["risk_grade"].dropna().astype(str).unique()) if has(perf, ["risk_grade"]) else []
    selected_categories = st.multiselect("Scheme category", categories, default=categories)
    selected_houses = st.multiselect("Fund house", houses, default=houses)
    selected_risks = st.multiselect("Risk grade", risks, default=risks)

filtered = perf.copy()
if not filtered.empty:
    if categories and selected_categories:
        filtered = filtered[filtered["category"].astype(str).isin(selected_categories)]
    elif categories:
        filtered = filtered.iloc[0:0]
    if houses and selected_houses:
        filtered = filtered[filtered["fund_house"].astype(str).isin(selected_houses)]
    elif houses:
        filtered = filtered.iloc[0:0]
    if risks and selected_risks:
        filtered = filtered[filtered["risk_grade"].astype(str).isin(selected_risks)]
    elif risks:
        filtered = filtered.iloc[0:0]

def metric_latest(frame, date_col, value_col):
    if has(frame, [date_col, value_col]):
        valid = frame.dropna(subset=[date_col]).sort_values(date_col)
        return None if valid.empty else valid.iloc[-1][value_col]
    return None

latest_aum = metric_latest(aum, "date", "aum_lakh_crore")
latest_sip = metric_latest(sip, "month", "sip_inflow_crore")
latest_folios = metric_latest(folios, "month", "total_folios_crore")
m1, m2, m3, m4 = st.columns(4)
m1.metric("Fund houses covered", f"{aum['fund_house'].nunique():,}" if has(aum, ["fund_house"]) else "—")
m2.metric("Latest reported AUM", f"₹{latest_aum:,.2f} lakh crore" if latest_aum is not None else "—")
m3.metric("Latest monthly SIP inflow", f"₹{latest_sip:,.0f} crore" if latest_sip is not None else "—")
m4.metric("Latest folios", f"{latest_folios:,.2f} crore" if latest_folios is not None else "—")

overview, scheme_tab, risk_tab, investor_tab, holdings_tab, coverage_tab = st.tabs([
    "Market Overview", "Scheme Performance", "Risk Analytics",
    "Investor Insights", "Portfolio Holdings", "Data Coverage"
])

with overview:
    st.subheader("Market overview")
    left, right = st.columns(2)
    if has(aum, ["date", "fund_house", "aum_crore"]):
        latest_date = aum["date"].max()
        snap = aum[aum["date"] == latest_date].nlargest(12, "aum_crore")
        left.plotly_chart(px.bar(snap, x="fund_house", y="aum_crore",
            title=f"Top fund houses by AUM · {latest_date:%b %Y}", labels={"aum_crore":"AUM (₹ crore)"}),
            use_container_width=True)
        trend = aum.groupby("date", as_index=False)["aum_crore"].sum()
        right.plotly_chart(px.line(trend, x="date", y="aum_crore", markers=True,
            title="Reported AUM trend · ₹ crore"), use_container_width=True)
    if has(sip, ["month", "sip_inflow_crore"]):
        st.plotly_chart(px.line(sip.sort_values("month"), x="month", y="sip_inflow_crore",
            markers=True, title="Monthly SIP inflows · ₹ crore"), use_container_width=True)
    if has(inflows, ["month", "category", "net_inflow_crore"]):
        pivot = inflows.pivot_table(index="month", columns="category",
            values="net_inflow_crore", aggfunc="sum").reset_index()
        st.plotly_chart(px.area(pivot, x="month", y=[c for c in pivot.columns if c != "month"],
            title="Category-wise net inflows · ₹ crore"), use_container_width=True)
    if has(folios, ["month", "total_folios_crore"]):
        st.plotly_chart(px.line(folios.sort_values("month"), x="month", y="total_folios_crore",
            markers=True, title="Industry folio growth · crore"), use_container_width=True)

with scheme_tab:
    st.subheader("Scheme performance comparison")
    if filtered.empty:
        st.info("No schemes match the selected filters. Select at least one category, fund house and risk grade.")
    else:
        metric_options = [c for c in ["return_1yr_pct", "return_3yr_pct", "return_5yr_pct",
            "sharpe_ratio", "sortino_ratio", "alpha"] if c in filtered.columns]
        metric = st.selectbox("Rank schemes by", metric_options, index=2 if "return_5yr_pct" in metric_options else 0)
        top = filtered.nlargest(min(15, len(filtered)), metric).sort_values(metric)
        st.plotly_chart(px.bar(top, x=metric, y="scheme_name", color="category",
            orientation="h", title=f"Top schemes by {metric}"), use_container_width=True)
        display_cols = [c for c in ["scheme_name","fund_house","category","return_1yr_pct",
            "return_3yr_pct","return_5yr_pct","sharpe_ratio","sortino_ratio",
            "max_drawdown_pct","expense_ratio_pct","risk_grade"] if c in filtered.columns]
        st.dataframe(filtered[display_cols].sort_values(metric, ascending=False),
            use_container_width=True, hide_index=True)

with risk_tab:
    st.subheader("Risk and return analysis")
    if has(filtered, ["std_dev_ann_pct", "return_3yr_pct", "risk_grade", "scheme_name"]):
        c1, c2 = st.columns(2)
        size_col = "aum_crore" if "aum_crore" in filtered.columns else None
        c1.plotly_chart(px.scatter(filtered, x="std_dev_ann_pct", y="return_3yr_pct",
            color="risk_grade", size=size_col, hover_name="scheme_name",
            title="Annualised volatility vs 3-year return"), use_container_width=True)
        if has(filtered, ["max_drawdown_pct", "sharpe_ratio", "category"]):
            c2.plotly_chart(px.scatter(filtered, x="max_drawdown_pct", y="sharpe_ratio",
                color="category", hover_name="scheme_name",
                title="Maximum drawdown vs Sharpe ratio"), use_container_width=True)
        st.plotly_chart(px.box(filtered, x="risk_grade", y="std_dev_ann_pct",
            color="risk_grade", title="Volatility distribution by risk grade"), use_container_width=True)
        st.caption("Risk indicators are the scheme-level snapshot metrics supplied in the dataset; they are not recomputed from daily NAV.")
    else:
        st.info("Risk fields are not available in the supplied scheme-performance file.")

with investor_tab:
    st.subheader("Investor transaction insights")
    if has(tx, ["amount_inr", "age_group", "state", "transaction_type", "payment_mode"]):
        c1, c2 = st.columns(2)
        age = tx.groupby("age_group", as_index=False)["amount_inr"].sum().sort_values("amount_inr", ascending=False)
        states = tx.groupby("state", as_index=False)["amount_inr"].sum().nlargest(12, "amount_inr")
        c1.plotly_chart(px.bar(age, x="age_group", y="amount_inr", title="Transaction value by age group · ₹"), use_container_width=True)
        c2.plotly_chart(px.bar(states, x="state", y="amount_inr", title="Top states by transaction value · ₹"), use_container_width=True)
        c3, c4 = st.columns(2)
        c3.plotly_chart(px.pie(tx, names="transaction_type", values="amount_inr", title="Transaction type mix by value"), use_container_width=True)
        c4.plotly_chart(px.pie(tx, names="payment_mode", values="amount_inr", title="Payment mode mix by value"), use_container_width=True)
        st.metric("Transaction records", f"{len(tx):,}")
        if "kyc_status" in tx:
            kyc = tx["kyc_status"].value_counts(dropna=False).rename_axis("kyc_status").reset_index(name="records")
            st.plotly_chart(px.bar(kyc, x="kyc_status", y="records", title="KYC status · transaction records"), use_container_width=True)
    else:
        st.info("Investor transaction fields are not available.")

with holdings_tab:
    st.subheader("Portfolio holdings analysis")
    if has(holdings, ["sector", "weight_pct", "stock_name"]):
        c1, c2 = st.columns(2)
        sector = holdings.groupby("sector", as_index=False)["weight_pct"].sum().nlargest(12, "weight_pct")
        stocks = holdings.groupby("stock_name", as_index=False)["weight_pct"].sum().nlargest(15, "weight_pct").sort_values("weight_pct")
        c1.plotly_chart(px.pie(sector, names="sector", values="weight_pct", title="Aggregated reported sector weights"), use_container_width=True)
        c2.plotly_chart(px.bar(stocks, x="weight_pct", y="stock_name", orientation="h", title="Top underlying stocks by summed reported weight"), use_container_width=True)
        show_cols = [c for c in ["amfi_code","stock_symbol","stock_name","sector","weight_pct","market_value_cr","portfolio_date"] if c in holdings.columns]
        st.dataframe(holdings[show_cols].sort_values("weight_pct", ascending=False), use_container_width=True, hide_index=True)
        st.caption("Weights are summed across the supplied scheme holdings rows; they are not AUM-weighted market-wide allocations.")
    else:
        st.info("Portfolio holdings fields are not available.")

with coverage_tab:
    st.subheader("Bundled dataset coverage")
    rows = []
    for key, filename in FILES.items():
        frame = data[key]
        rows.append({"Dataset": filename, "Rows": len(frame), "Columns": len(frame.columns),
            "Missing cells": int(frame.isna().sum().sum()) if not frame.empty else 0,
            "Status": "Loaded" if not frame.empty else "Missing / empty"})
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
    st.write("All data is read from the CSV files in the dashboard's `data/` directory. No live API connection is configured.")
    st.warning("This is an analytical dashboard, not investment advice. Metrics and dates reflect the supplied datasets only.")

st.caption("Bluestock Mutual Fund Analytics · Streamlit + Plotly")
