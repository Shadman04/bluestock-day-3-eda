"""Validate Bluestock datasets and provide the dashboard launch command."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parent
DASHBOARD_DATA = ROOT / "dashboard" / "data"
EXPECTED = {
    "aum_by_fund_house.csv": ["date", "fund_house", "aum_crore"],
    "monthly_sip_inflows.csv": ["month", "sip_inflow_crore"],
    "category_inflows.csv": ["month", "category", "net_inflow_crore"],
    "industry_folio_count.csv": ["month", "total_folios_crore"],
    "scheme_performance.csv": ["amfi_code", "scheme_name", "return_3yr_pct", "sharpe_ratio"],
    "fund_master.csv": ["amfi_code", "scheme_name", "fund_house"],
    "investor_transactions.csv": ["investor_id", "transaction_date", "amount_inr"],
    "portfolio_holdings.csv": ["amfi_code", "stock_symbol", "sector", "weight_pct"],
    "benchmark_indices.csv": ["date", "index_name", "close_value"],
}

def validate_datasets() -> None:
    """Validate presence, readability, non-empty rows and required columns."""
    failures = []
    for filename, required in EXPECTED.items():
        path = DASHBOARD_DATA / filename
        if not path.exists():
            failures.append(f"Missing file: {filename}")
            continue
        try:
            frame = pd.read_csv(path)
        except Exception as exc:  # report the filename and continue checking others
            failures.append(f"Cannot read {filename}: {exc}")
            continue
        missing = [column for column in required if column not in frame.columns]
        if frame.empty:
            failures.append(f"Empty dataset: {filename}")
        if missing:
            failures.append(f"{filename} missing columns: {missing}")
        if not missing and not frame.empty:
            print(f"OK  {filename}: {len(frame):,} rows × {len(frame.columns)} columns")
    if failures:
        raise SystemExit("Dataset validation failed:\n- " + "\n- ".join(failures))
    print("\nAll nine dashboard datasets passed validation.")
    print("Launch dashboard: python -m streamlit run dashboard/app.py")

if __name__ == "__main__":
    validate_datasets()
